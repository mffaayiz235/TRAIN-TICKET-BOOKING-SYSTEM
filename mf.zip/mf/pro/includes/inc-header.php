<!DOCTYPE html>
<html>
<?php
require_once '../constants.php';

?>

<head>
    <title><?php echo SITE_NAME ?></title>
    <link href="assets/css/jquery-ui.css" rel="stylesheet" type="text/csss" />
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="assets/css/style.css">
</head>