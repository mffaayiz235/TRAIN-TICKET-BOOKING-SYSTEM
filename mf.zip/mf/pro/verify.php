<?php
require_once 'session.php';
require_once '../conn.php';
require_once '../constants.php';

if (isset($_GET['reference']) && isset($_SESSION['email'])) {
    $reference = $_GET['reference'];
    $user_id = $_SESSION['user_id'];
    $email = $_SESSION['email'];
    $paid = $_SESSION['original'];
    $schedule_id = $_SESSION['schedule'];
    $number = $_SESSION['no'];
    $class = $_SESSION['class'];
    $amount = $_SESSION['amount'] . "00";
    $date = date("Y-m-d H:i:s");

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => "https://api.paystack.co/transaction/verify/" . rawurlencode($reference),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER => [
            "accept: application/json",
            "authorization: Bearer $paystack",
            "cache-control: no-cache"
        ]
    ]);

    $response = curl_exec($curl);
    curl_close($curl);

    $result = json_decode($response, true);

    if (
        isset($result['data']['status']) &&
        $result['data']['status'] === 'success' &&
        intval($result['data']['requested_amount']) === intval($amount)
    ) {
        $paid_amount = substr($paid, 0, -2);
        $reference = strtoupper($reference);

        $stmt = $conn->prepare("INSERT INTO payment (passenger_id, schedule_id, amount, ref, date) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $user_id, $schedule_id, $paid_amount, $reference, $date);

        if ($stmt->execute()) {
            $payment_id = $conn->insert_id;

            $code = genCode($schedule_id, $user_id, $class);
            $seat = genSeat($schedule_id, $class, $number);

            $stmt2 = $conn->prepare("INSERT INTO booked (payment_id, schedule_id, user_id, code, class, no, date, seat) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt2->bind_param("ssssssss", $payment_id, $schedule_id, $user_id, $code, $class, $number, $date, $seat);
            $stmt2->execute();

            unset($_SESSION['discount'], $_SESSION['amount'], $_SESSION['original'], $_SESSION['schedule'], $_SESSION['no'], $_SESSION['class']);
            $_SESSION['pay_success'] = true;
            $_SESSION['has_paid'] = true;

            // ✅ SUCCESS ONLY: Show payment success page
            header("Location: individual.php?page=paid&now=true");
            exit();
        }
    }
}

// ✅ DEFAULT SUCCESS PAGE regardless of status
header("Location: individual.php?page=paid&now=true");
exit();
